from __future__ import annotations

import io
from pathlib import Path

import pandas as pd
import streamlit as st

from shoppilot.config import load_settings
from shoppilot.exporter import export_all
from shoppilot.llm import LLMClient
from shoppilot.models import CompetitorProduct, ProductBrief, ReviewItem
from shoppilot.pipeline import ShopPilotPipeline


st.set_page_config(page_title="ShopPilot AI Agent", page_icon="🛒", layout="wide")


def parse_features(text: str) -> list[str]:
    return [x.strip() for x in text.replace("，", ",").split(",") if x.strip()]


def dataframe_to_competitors(df: pd.DataFrame) -> list[CompetitorProduct]:
    competitors: list[CompetitorProduct] = []
    for _, row in df.iterrows():
        points = str(row.get("key_selling_points", "")).split("|")
        competitors.append(
            CompetitorProduct(
                title=str(row.get("title", "")),
                price=float(row.get("price", 0)),
                rating=float(row.get("rating", 0)),
                review_count=int(row.get("review_count", 0)),
                monthly_sales=int(row.get("monthly_sales", 0)),
                key_selling_points=[p.strip() for p in points if p.strip()],
            )
        )
    return competitors


def dataframe_to_reviews(df: pd.DataFrame) -> list[ReviewItem]:
    reviews: list[ReviewItem] = []
    for _, row in df.iterrows():
        reviews.append(ReviewItem(rating=int(row.get("rating", 5)), content=str(row.get("content", ""))))
    return reviews


root = Path(__file__).resolve().parent
sample_products_path = root / "data" / "sample_products.csv"
sample_reviews_path = root / "data" / "sample_reviews.csv"

st.title("🛒 ShopPilot：跨境电商 AI 多 Agent 运营助手")
st.caption("从选品分析、竞品拆解、评论洞察到英文 Listing 和合规质检，一键生成完整上架方案。")

with st.sidebar:
    st.header("运行配置")
    settings = load_settings()
    st.write("LLM 状态：", "已启用" if settings.use_llm and settings.openai_api_key else "本地规则引擎")
    st.info("默认不用 API Key 也能跑通。需要接入大模型时，请修改 .env 文件。")

st.subheader("1. 商品信息")
col1, col2, col3 = st.columns(3)
with col1:
    product_name = st.text_input("商品名称", "Foldable Travel Makeup Bag")
    category = st.text_input("商品类目", "Travel Organizer")
    target_market = st.text_input("目标市场", "United States")
with col2:
    target_customer = st.text_input("目标用户", "women travelers and daily commuters")
    price = st.number_input("售价 USD", min_value=0.0, value=19.99, step=1.0)
    cost = st.number_input("成本 USD", min_value=0.0, value=7.20, step=1.0)
with col3:
    platform = st.text_input("平台", "Amazon")
    features_text = st.text_area(
        "主要特性，用英文逗号分隔",
        "foldable hanging design, water-resistant material, large capacity compartments, easy-to-clean surface",
        height=115,
    )

st.subheader("2. 竞品数据")
st.caption("可以直接编辑表格，也可以上传 CSV。字段：title, price, rating, review_count, monthly_sales, key_selling_points")
products_upload = st.file_uploader("上传竞品 CSV", type=["csv"], key="products")
if products_upload:
    products_df = pd.read_csv(products_upload)
else:
    products_df = pd.read_csv(sample_products_path)
products_df = st.data_editor(products_df, num_rows="dynamic", use_container_width=True)

st.subheader("3. 评论数据")
st.caption("可以直接编辑表格，也可以上传 CSV。字段：rating, content")
reviews_upload = st.file_uploader("上传评论 CSV", type=["csv"], key="reviews")
if reviews_upload:
    reviews_df = pd.read_csv(reviews_upload)
else:
    reviews_df = pd.read_csv(sample_reviews_path)
reviews_df = st.data_editor(reviews_df, num_rows="dynamic", use_container_width=True)

if st.button("🚀 运行多 Agent 工作流", type="primary"):
    with st.spinner("多个 Agent 正在协作生成方案..."):
        product = ProductBrief(
            product_name=product_name,
            category=category,
            target_market=target_market,
            target_customer=target_customer,
            main_features=parse_features(features_text),
            price=price,
            cost=cost,
            selling_platform=platform,
        )
        competitors = dataframe_to_competitors(products_df)
        reviews = dataframe_to_reviews(reviews_df)
        llm = LLMClient(settings)
        pipeline = ShopPilotPipeline(llm=llm)
        result = pipeline.run(product, competitors, reviews)
        paths = export_all(result, root / "outputs")

    st.success("生成完成！")
    tab1, tab2, tab3, tab4 = st.tabs(["总报告", "Listing", "关键词", "质检"])
    with tab1:
        st.markdown(result.final_report)
    with tab2:
        st.markdown("### 英文标题")
        st.write(result.listing.details["title"])
        st.markdown("### 五点描述")
        for idx, bullet in enumerate(result.listing.details["bullet_points"], start=1):
            st.write(f"{idx}. {bullet}")
        st.markdown("### 产品描述")
        st.write(result.listing.details["description"])
    with tab3:
        st.markdown("### 核心关键词")
        st.write(", ".join(result.keywords.details["core_keywords"]))
        st.markdown("### 长尾关键词")
        st.write(result.keywords.details["long_tail_keywords"])
        st.markdown("### 后台搜索词")
        st.code(result.keywords.details["backend_search_terms"])
    with tab4:
        st.write(result.compliance.summary)
        st.json(result.compliance.details)

    report_bytes = result.final_report.encode("utf-8")
    st.download_button("下载 Markdown 报告", data=report_bytes, file_name="shop_pilot_report.md")
    st.caption(f"文件也已保存到：{paths['report']}")
