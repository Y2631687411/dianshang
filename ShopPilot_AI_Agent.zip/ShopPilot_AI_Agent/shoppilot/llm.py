from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from .config import Settings


@dataclass
class LLMClient:
    """Small wrapper around OpenAI-compatible chat completions.

    The project runs without an LLM. If USE_LLM=true and OPENAI_API_KEY is set,
    selected agents can use this client to polish or expand generated text.
    """

    settings: Settings

    def available(self) -> bool:
        return bool(self.settings.use_llm and self.settings.openai_api_key)

    def chat(self, system_prompt: str, user_prompt: str, temperature: float = 0.4) -> Optional[str]:
        if not self.available():
            return None
        try:
            from openai import OpenAI

            client = OpenAI(
                api_key=self.settings.openai_api_key,
                base_url=self.settings.openai_base_url,
            )
            response = client.chat.completions.create(
                model=self.settings.openai_model,
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt},
                ],
                temperature=temperature,
            )
            return response.choices[0].message.content or ""
        except Exception as exc:  # noqa: BLE001
            return f"[LLM 调用失败，已回退本地规则引擎] {exc}"
