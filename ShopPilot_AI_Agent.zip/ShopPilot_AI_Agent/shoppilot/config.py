from __future__ import annotations

import os
from dataclasses import dataclass
from dotenv import load_dotenv


@dataclass
class Settings:
    """Runtime settings for ShopPilot."""

    use_llm: bool = False
    openai_api_key: str = ""
    openai_base_url: str = "https://api.openai.com/v1"
    openai_model: str = "gpt-4.1-mini"
    output_language: str = "zh"


def load_settings() -> Settings:
    """Load settings from .env and environment variables."""
    load_dotenv()
    use_llm_value = os.getenv("USE_LLM", "false").strip().lower()
    return Settings(
        use_llm=use_llm_value in {"1", "true", "yes", "y", "on"},
        openai_api_key=os.getenv("OPENAI_API_KEY", "").strip(),
        openai_base_url=os.getenv("OPENAI_BASE_URL", "https://api.openai.com/v1").strip(),
        openai_model=os.getenv("OPENAI_MODEL", "gpt-4.1-mini").strip(),
        output_language=os.getenv("OUTPUT_LANGUAGE", "zh").strip().lower(),
    )
