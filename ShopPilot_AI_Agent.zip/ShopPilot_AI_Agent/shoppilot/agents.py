from __future__ import annotations

import math
import re
from collections import Counter
from statistics import mean
from typing import Iterable

from .llm import LLMClient
from .models import AgentResult, CompetitorProduct, ProductBrief, ReviewItem


STOPWORDS = {
    "the", "and", "for", "with", "this", "that", "are", "was", "but", "you", "your",
    "very", "have", "has", "had", "not", "too", "from", "they", "them", "our", "out",
    "use", "used", "using", "can", "will", "just", "like", "good", "great", "nice",
    "product", "item", "one", "more", "than", "when", "what", "which", "would",
}

RISK_TERMS = {
    "best": "绝对化用语，建议改成 more reliable / designed for / ideal for",
    "number one": "绝对化排名，除非有真实证明，否则不要使用",
    "guaranteed": "保证性承诺，可能带来平台合规风险",
    "cure": "医疗化表达，普通消费品不要使用",
    "treat": "医疗化表达，普通消费品不要使用",
    "100%": "绝对化承诺，建议弱化",
    "permanent": "永久性承诺，建议弱化",
    "no risk": "零风险承诺，建议弱化",
}


def clean_words(text: str) -> list[str]:
    words = re.findall(r"[a-zA-Z][a-zA-Z0-9\-]{2,}", text.lower())
    return [w for w in words if w not in STOPWORDS]


def money(value: float) -> str:
    return f"${value:,.2f}"


class BaseAgent:
    def __init__(self, llm: LLMClient | None = None):
        self.llm = llm

    @property
    def name(self) -> str:
        return self.__class__.__name__


class ProductResearchAgent(BaseAgent):
    """Analyze whether the product is worth listing."""

    def run(self, product: ProductBrief, competitors: list[CompetitorProduct]) -> AgentResult:
        avg_price = mean([c.price for c in competitors]) if competitors else product.price
        avg_rating = mean([c.rating for c in competitors]) if competitors else 0
        avg_reviews = mean([c.review_count for c in competitors]) if competitors else 0
        avg_sales = mean([c.monthly_sales for c in competitors]) if competitors else 0
        margin = product.gross_margin_rate

        price_score = 100 - min(abs(product.price - avg_price) / max(avg_price, 1) * 100, 60)
        margin_score = min(max(margin * 180, 0), 100)
        competition_penalty = min(avg_reviews / 100, 35)
        demand_score = min(math.log(avg_sales + 1, 10) * 35, 100)
        final_score = round(0.30 * price_score + 0.30 * margin_score + 0.25 * demand_score + 0.15 * (100 - competition_penalty), 1)

        if final_score >= 78:
            decision = "建议优先上架"
        elif final_score >= 62:
            decision = "可以测试上架，但需要差异化卖点"
        else:
            decision = "不建议直接上架，建议重新选品或降低成本"

        summary = (
            f"选品综合评分 {final_score}/100，{decision}。"
            f"目标售价 {money(product.price)}，竞品均价 {money(avg_price)}，"
            f"毛利率约 {margin:.1%}，竞品平均评分 {avg_rating:.2f}。"
        )

        details = {
            "decision": decision,
            "score": final_score,
            "product_price": product.price,
            "avg_competitor_price": round(avg_price, 2),
            "gross_margin_rate": margin,
            "avg_competitor_rating": round(avg_rating, 2),
            "avg_competitor_reviews": round(avg_reviews, 1),
            "avg_monthly_sales": round(avg_sales, 1),
            "suggestions": [
                "如果价格高于竞品，需要在材质、套装数量、场景图片或售后承诺上做差异化。",
                "优先将主图卖点集中在 3 秒内可理解的痛点，例如 durability、space-saving、easy to clean。",
                "首批投放建议先小预算测试关键词转化，再决定是否扩大库存。",
            ],
        }
        return AgentResult(self.name, summary, details)


class CompetitorAnalysisAgent(BaseAgent):
    """Summarize competitor positioning and whitespace."""

    def run(self, product: ProductBrief, competitors: list[CompetitorProduct]) -> AgentResult:
        prices = [c.price for c in competitors] or [product.price]
        ratings = [c.rating for c in competitors] or [0]
        sales = [c.monthly_sales for c in competitors] or [0]
        all_points: list[str] = []
        title_words: list[str] = []
        for item in competitors:
            all_points.extend(item.key_selling_points)
            title_words.extend(clean_words(item.title))

        common_points = [p for p, _ in Counter(all_points).most_common(8)]
        title_keywords = [w for w, _ in Counter(title_words).most_common(12)]
        whitespace = [
            "把竞品常见卖点从功能描述升级为具体使用场景",
            "突出包装组合、耐用性和清洁便利性，避免只拼低价",
            "用差评中的问题反向设计卖点，例如 better fit、sturdier material、clear size guide",
        ]

        summary = (
            f"竞品价格区间为 {money(min(prices))} - {money(max(prices))}，"
            f"平均评分 {mean(ratings):.2f}，样本平均月销量约 {mean(sales):.0f}。"
            "当前竞争重点集中在功能、价格和场景表达，仍有差异化空间。"
        )
        return AgentResult(
            self.name,
            summary,
            {
                "price_range": [round(min(prices), 2), round(max(prices), 2)],
                "average_rating": round(mean(ratings), 2),
                "average_monthly_sales": round(mean(sales), 1),
                "common_selling_points": common_points,
                "frequent_title_keywords": title_keywords,
                "differentiation_opportunities": whitespace,
                "competitor_count": len(competitors),
            },
        )


class ReviewInsightAgent(BaseAgent):
    """Extract pain points and customer language from reviews."""

    def run(self, reviews: list[ReviewItem]) -> AgentResult:
        negative = [r for r in reviews if r.rating <= 3]
        positive = [r for r in reviews if r.rating >= 4]
        all_words = []
        negative_words = []
        for r in reviews:
            all_words.extend(clean_words(r.content))
        for r in negative:
            negative_words.extend(clean_words(r.content))

        top_words = [w for w, _ in Counter(all_words).most_common(12)]
        pain_words = [w for w, _ in Counter(negative_words).most_common(10)]

        pain_point_rules = {
            "quality": ["quality", "cheap", "broken", "durable", "sturdy", "flimsy"],
            "size_fit": ["size", "small", "large", "fit", "fits", "tight"],
            "delivery_packaging": ["delivery", "shipping", "package", "packaging", "damaged"],
            "usability": ["hard", "easy", "install", "clean", "use", "setup"],
            "appearance": ["color", "look", "design", "style", "photo"],
        }
        detected: dict[str, int] = {}
        corpus = " ".join(r.content.lower() for r in reviews)
        for name, words in pain_point_rules.items():
            detected[name] = sum(corpus.count(w) for w in words)

        sorted_pain_types = [k for k, v in sorted(detected.items(), key=lambda x: x[1], reverse=True) if v > 0]
        insights = [
            "买家最容易被具体、可验证的卖点打动，例如尺寸、材质、清洁方式和使用场景。",
            "差评中出现的问题应转化为详情页 FAQ 和图片说明，减少售前疑虑。",
            "五点描述不要只写功能，要写功能带来的实际好处。",
        ]
        summary = (
            f"共分析 {len(reviews)} 条评论，其中正向评论 {len(positive)} 条，负向/中性评论 {len(negative)} 条。"
            f"高频用户语言包括：{', '.join(top_words[:6])}。"
        )
        return AgentResult(
            self.name,
            summary,
            {
                "review_count": len(reviews),
                "positive_count": len(positive),
                "negative_or_neutral_count": len(negative),
                "top_customer_words": top_words,
                "negative_pain_words": pain_words,
                "detected_pain_types": sorted_pain_types,
                "insights": insights,
            },
        )


class ListingWriterAgent(BaseAgent):
    """Generate English listing copy."""

    def run(
        self,
        product: ProductBrief,
        competitor_result: AgentResult,
        review_result: AgentResult,
    ) -> AgentResult:
        features = product.main_features[:]
        customer = product.target_customer
        core_keywords = competitor_result.details.get("frequent_title_keywords", [])[:6]
        pain_types = review_result.details.get("detected_pain_types", [])[:3]

        title_parts = [
            product.product_name,
            "for",
            customer,
            *features[:3],
        ]
        if core_keywords:
            title_parts.extend(core_keywords[:3])
        title = " ".join(title_parts)
        title = re.sub(r"\s+", " ", title).strip()[:190]

        benefit_map = {
            "quality": "Built for daily use with a practical design that helps reduce common quality concerns.",
            "size_fit": "Clear sizing guidance helps customers choose the right fit before purchase.",
            "delivery_packaging": "Designed with simple packaging and easy setup in mind.",
            "usability": "Easy to use, clean, and store, making it suitable for busy everyday routines.",
            "appearance": "Clean modern look blends naturally with different home and lifestyle scenes.",
        }
        bullets = [
            f"Practical Design: {features[0] if features else 'Designed for everyday use'} for {customer}.",
            f"Better User Experience: {benefit_map.get(pain_types[0], 'Focuses on the details buyers mention most in reviews.') if pain_types else 'Focuses on the details buyers mention most in reviews.'}",
            f"Easy to Use: Simple setup and daily operation help reduce time spent on repetitive tasks.",
            f"Versatile Scenario: Suitable for {product.target_market} customers across home, office, travel, or gifting use cases.",
            f"Value Package: Positioned at {money(product.price)} with a balance of function, quality, and affordability.",
        ]
        description = (
            f"Upgrade your everyday routine with {product.product_name}. "
            f"Designed for {customer}, this product focuses on practical details, clear usability, "
            f"and a balanced price point. It is ideal for shoppers who want a simple, reliable, "
            f"and easy-to-understand solution without overcomplicated features."
        )
        ads = [
            f"Make daily life easier with {product.product_name}.",
            f"A practical choice for {customer}.",
            "Simple design, useful features, better everyday experience.",
        ]

        # Optional LLM polish. Keep it safe: use local version if no LLM configured.
        if self.llm and self.llm.available():
            prompt = f"""
Please polish this Amazon-style listing in natural English. Avoid exaggerated claims.
Product: {product.to_dict()}
Draft title: {title}
Draft bullets: {bullets}
Draft description: {description}
Return concise JSON-like text with title, bullets, description, ads.
""".strip()
            llm_text = self.llm.chat(
                system_prompt="You are a careful ecommerce listing copywriter. Avoid medical, ranking, or guaranteed claims.",
                user_prompt=prompt,
            )
        else:
            llm_text = None

        details = {
            "title": title,
            "bullet_points": bullets,
            "description": description,
            "ad_copies": ads,
            "llm_polished_text": llm_text,
        }
        summary = "已生成英文标题、五点描述、详情页描述和广告短句，可直接用于 Listing 初稿。"
        return AgentResult(self.name, summary, details)


class KeywordAgent(BaseAgent):
    """Generate keyword strategy."""

    def run(
        self,
        product: ProductBrief,
        competitors: list[CompetitorProduct],
        reviews: list[ReviewItem],
    ) -> AgentResult:
        text_pool = [product.product_name, product.category, product.target_customer]
        text_pool.extend(product.main_features)
        text_pool.extend(c.title for c in competitors)
        for c in competitors:
            text_pool.extend(c.key_selling_points)
        text_pool.extend(r.content for r in reviews)
        words = clean_words(" ".join(text_pool))
        frequent = [w for w, _ in Counter(words).most_common(30)]

        product_base = product.product_name.lower()
        core = list(dict.fromkeys([product_base, product.category.lower(), *frequent[:8]]))[:10]
        long_tail = [
            f"{product_base} for {product.target_customer.lower()}",
            f"{product.category.lower()} for {product.target_market.lower()}",
            f"easy to use {product.category.lower()}",
            f"durable {product.category.lower()}",
            f"gift for {product.target_customer.lower()}",
        ]
        backend = " ".join(dict.fromkeys(frequent[:40]))[:240]
        summary = f"已生成 {len(core)} 个核心关键词、{len(long_tail)} 个长尾关键词，并生成后台搜索词草稿。"
        return AgentResult(
            self.name,
            summary,
            {
                "core_keywords": core,
                "long_tail_keywords": long_tail,
                "backend_search_terms": backend,
                "keyword_note": "核心关键词放标题和五点，长尾词用于广告组和详情页，后台词避免重复和品牌侵权。",
            },
        )


class ComplianceAgent(BaseAgent):
    """Check copywriting risks."""

    def run(self, listing_result: AgentResult) -> AgentResult:
        listing_text = " ".join(
            [
                listing_result.details.get("title", ""),
                " ".join(listing_result.details.get("bullet_points", [])),
                listing_result.details.get("description", ""),
                " ".join(listing_result.details.get("ad_copies", [])),
            ]
        ).lower()
        risks = []
        for term, reason in RISK_TERMS.items():
            if term in listing_text:
                risks.append({"term": term, "reason": reason})

        if risks:
            level = "需要修改"
            summary = f"发现 {len(risks)} 个潜在合规风险，建议发布前替换。"
        else:
            level = "低风险"
            summary = "未发现明显绝对化、医疗化或保证性表述，当前 Listing 初稿风险较低。"
        return AgentResult(
            self.name,
            summary,
            {
                "risk_level": level,
                "risks": risks,
                "safe_copywriting_rules": [
                    "避免使用 best、No.1、guaranteed、100% 等绝对化表达。",
                    "非医疗产品避免使用 cure、treat、heal 等医疗化表达。",
                    "功能描述尽量可验证，例如 material、size、package、usage scenario。",
                    "不要使用竞品品牌词作为后台搜索词。",
                ],
            },
        )


class ReportAgent(BaseAgent):
    """Build final markdown report."""

    def run(
        self,
        product: ProductBrief,
        research: AgentResult,
        competitor: AgentResult,
        review: AgentResult,
        listing: AgentResult,
        keywords: AgentResult,
        compliance: AgentResult,
    ) -> str:
        bullets = listing.details.get("bullet_points", [])
        core_keywords = keywords.details.get("core_keywords", [])
        long_tail = keywords.details.get("long_tail_keywords", [])
        ad_copies = listing.details.get("ad_copies", [])
        common_points = competitor.details.get("common_selling_points", [])
        opportunities = competitor.details.get("differentiation_opportunities", [])
        insights = review.details.get("insights", [])

        return f"""# ShopPilot 跨境电商 AI Agent 运营报告

## 1. 商品基本信息

- 商品名称：{product.product_name}
- 类目：{product.category}
- 目标市场：{product.target_market}
- 目标用户：{product.target_customer}
- 计划售价：{money(product.price)}
- 估算成本：{money(product.cost)}
- 估算毛利率：{product.gross_margin_rate:.1%}
- 主要特性：{', '.join(product.main_features)}

## 2. 选品分析 Agent 结论

{research.summary}

- 上架建议：{research.details.get('decision')}
- 综合评分：{research.details.get('score')}/100
- 竞品均价：{money(research.details.get('avg_competitor_price', 0))}
- 竞品平均评分：{research.details.get('avg_competitor_rating')}
- 样本平均月销量：{research.details.get('avg_monthly_sales')}

### 行动建议

{chr(10).join(f'- {x}' for x in research.details.get('suggestions', []))}

## 3. 竞品研究 Agent 结论

{competitor.summary}

### 竞品常见卖点

{chr(10).join(f'- {x}' for x in common_points) if common_points else '- 暂无'}

### 差异化机会

{chr(10).join(f'- {x}' for x in opportunities)}

## 4. 用户评论洞察 Agent 结论

{review.summary}

### 高频用户语言

{', '.join(review.details.get('top_customer_words', [])[:15])}

### 负面痛点词

{', '.join(review.details.get('negative_pain_words', [])[:12]) or '暂无明显负面痛点'}

### 洞察建议

{chr(10).join(f'- {x}' for x in insights)}

## 5. Listing 文案 Agent 输出

### 英文标题

{listing.details.get('title')}

### 五点描述

{chr(10).join(f'{i+1}. {b}' for i, b in enumerate(bullets))}

### 产品描述

{listing.details.get('description')}

### 广告短句

{chr(10).join(f'- {x}' for x in ad_copies)}

## 6. 关键词优化 Agent 输出

### 核心关键词

{', '.join(core_keywords)}

### 长尾关键词

{chr(10).join(f'- {x}' for x in long_tail)}

### 后台搜索词草稿

{keywords.details.get('backend_search_terms')}

## 7. 合规质检 Agent 结论

{compliance.summary}

- 风险等级：{compliance.details.get('risk_level')}

### 安全文案规则

{chr(10).join(f'- {x}' for x in compliance.details.get('safe_copywriting_rules', []))}

## 8. 最终执行建议

1. 先用当前 Listing 初稿完成小批量上架测试。
2. 广告先投放核心词和 3-5 个长尾词，观察点击率和转化率。
3. 根据差评痛点补充主图标注、A+ 页面和 FAQ。
4. 若转化率低，优先优化主图和标题前 80 个字符。
5. 若点击率高但转化低，优先调整价格、优惠券和评论承接策略。
"""
