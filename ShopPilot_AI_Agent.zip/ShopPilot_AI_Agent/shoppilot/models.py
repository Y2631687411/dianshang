from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Any


@dataclass
class ProductBrief:
    product_name: str
    category: str
    target_market: str
    target_customer: str
    main_features: list[str]
    price: float
    cost: float
    selling_platform: str = "Amazon"

    @property
    def gross_margin_rate(self) -> float:
        if self.price <= 0:
            return 0.0
        return round((self.price - self.cost) / self.price, 4)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class CompetitorProduct:
    title: str
    price: float
    rating: float
    review_count: int
    monthly_sales: int
    key_selling_points: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class ReviewItem:
    rating: int
    content: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class AgentResult:
    agent_name: str
    summary: str
    details: dict[str, Any]

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class PipelineResult:
    product: ProductBrief
    research: AgentResult
    competitor_analysis: AgentResult
    review_insights: AgentResult
    listing: AgentResult
    keywords: AgentResult
    compliance: AgentResult
    final_report: str

    def to_dict(self) -> dict[str, Any]:
        return {
            "product": self.product.to_dict(),
            "research": self.research.to_dict(),
            "competitor_analysis": self.competitor_analysis.to_dict(),
            "review_insights": self.review_insights.to_dict(),
            "listing": self.listing.to_dict(),
            "keywords": self.keywords.to_dict(),
            "compliance": self.compliance.to_dict(),
            "final_report": self.final_report,
        }
