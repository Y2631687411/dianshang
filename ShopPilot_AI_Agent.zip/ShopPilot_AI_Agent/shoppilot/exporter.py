from __future__ import annotations

import json
from pathlib import Path

import pandas as pd

from .models import PipelineResult


def ensure_dir(path: str | Path) -> Path:
    out_dir = Path(path)
    out_dir.mkdir(parents=True, exist_ok=True)
    return out_dir


def export_all(result: PipelineResult, output_dir: str | Path = "outputs") -> dict[str, str]:
    out_dir = ensure_dir(output_dir)

    report_path = out_dir / "shop_pilot_report.md"
    json_path = out_dir / "listing_output.json"
    keyword_path = out_dir / "keywords.csv"

    report_path.write_text(result.final_report, encoding="utf-8")

    json_path.write_text(
        json.dumps(result.to_dict(), ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    keyword_rows = []
    for kw in result.keywords.details.get("core_keywords", []):
        keyword_rows.append({"type": "core", "keyword": kw})
    for kw in result.keywords.details.get("long_tail_keywords", []):
        keyword_rows.append({"type": "long_tail", "keyword": kw})
    keyword_rows.append({
        "type": "backend_search_terms",
        "keyword": result.keywords.details.get("backend_search_terms", ""),
    })
    pd.DataFrame(keyword_rows).to_csv(keyword_path, index=False, encoding="utf-8-sig")

    return {
        "report": str(report_path),
        "json": str(json_path),
        "keywords": str(keyword_path),
    }
