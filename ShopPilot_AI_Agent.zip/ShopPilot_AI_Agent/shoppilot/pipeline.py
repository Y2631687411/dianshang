from __future__ import annotations

from .agents import (
    ComplianceAgent,
    CompetitorAnalysisAgent,
    KeywordAgent,
    ListingWriterAgent,
    ProductResearchAgent,
    ReportAgent,
    ReviewInsightAgent,
)
from .llm import LLMClient
from .models import CompetitorProduct, PipelineResult, ProductBrief, ReviewItem


class ShopPilotPipeline:
    """Orchestrates all agents in a long-chain workflow."""

    def __init__(self, llm: LLMClient | None = None):
        self.llm = llm
        self.product_agent = ProductResearchAgent(llm)
        self.competitor_agent = CompetitorAnalysisAgent(llm)
        self.review_agent = ReviewInsightAgent(llm)
        self.listing_agent = ListingWriterAgent(llm)
        self.keyword_agent = KeywordAgent(llm)
        self.compliance_agent = ComplianceAgent(llm)
        self.report_agent = ReportAgent(llm)

    def run(
        self,
        product: ProductBrief,
        competitors: list[CompetitorProduct],
        reviews: list[ReviewItem],
    ) -> PipelineResult:
        research = self.product_agent.run(product, competitors)
        competitor_analysis = self.competitor_agent.run(product, competitors)
        review_insights = self.review_agent.run(reviews)
        listing = self.listing_agent.run(product, competitor_analysis, review_insights)
        keywords = self.keyword_agent.run(product, competitors, reviews)
        compliance = self.compliance_agent.run(listing)
        final_report = self.report_agent.run(
            product=product,
            research=research,
            competitor=competitor_analysis,
            review=review_insights,
            listing=listing,
            keywords=keywords,
            compliance=compliance,
        )
        return PipelineResult(
            product=product,
            research=research,
            competitor_analysis=competitor_analysis,
            review_insights=review_insights,
            listing=listing,
            keywords=keywords,
            compliance=compliance,
            final_report=final_report,
        )
