# ShopPilot：跨境电商 AI 多 Agent 运营助手

ShopPilot 是一个可以直接运行的跨境电商运营 Agent 项目。它模拟真实运营流程，自动完成：选品分析、竞品拆解、评论痛点提炼、英文 Listing 生成、关键词优化、合规质检和 Markdown 报告导出。

> 亮点：默认不需要 API Key，也可以离线跑通完整流程；如果你有 OpenAI 或其他 OpenAI-compatible 接口，可以在 `.env` 中配置，让文案生成更智能。

---

## 一、项目解决的核心痛点

跨境电商运营在上架商品前，需要人工完成大量重复工作：

1. 浏览大量竞品，判断价格带、销量、评分和竞争强度；
2. 阅读评论，提炼用户痛点和购买动机；
3. 撰写英文标题、五点描述、详情页文案、广告短句；
4. 整理关键词，同时避免关键词堆砌；
5. 检查文案是否夸大宣传、是否存在平台合规风险。

这些工作耗时、重复、依赖经验，新手运营很难稳定产出高质量 Listing。ShopPilot 将这些环节拆成多个 Agent，通过长链流程自动生成完整上架方案。

---

## 二、核心逻辑流

系统采用多 Agent 协作：

- `ProductResearchAgent`：分析目标商品、价格、评分、竞品密度，给出选品判断。
- `CompetitorAnalysisAgent`：拆解竞品标题、价格带、卖点和差异化机会。
- `ReviewInsightAgent`：从评论中提取用户痛点、需求、负面反馈和改进方向。
- `ListingWriterAgent`：生成英文标题、五点描述、产品描述和广告文案。
- `KeywordAgent`：生成核心关键词、长尾关键词和后台搜索词。
- `ComplianceAgent`：检查夸大宣传、绝对化用语、医疗化表述等风险。
- `ReportAgent`：整合所有结果，输出完整 Markdown 报告。

流程为：

```text
输入商品信息 + 竞品数据 + 评论数据
        ↓
选品分析 Agent
        ↓
竞品分析 Agent
        ↓
评论洞察 Agent
        ↓
Listing 文案 Agent
        ↓
关键词优化 Agent
        ↓
合规质检 Agent
        ↓
导出完整上架报告
```

---

## 三、快速运行

### 1. 安装依赖

```bash
pip install -r requirements.txt
```

### 2. 命令行运行

```bash
python run_cli.py
```

运行后会在 `outputs/` 目录生成：

- `shop_pilot_report.md`：完整运营报告
- `listing_output.json`：结构化结果
- `keywords.csv`：关键词表

### 3. 启动网页界面

```bash
streamlit run app.py
```

然后浏览器会打开一个本地网页，可以修改商品信息并一键生成方案。

---

## 四、可选：接入真实大模型 API

项目默认使用本地规则引擎，不需要 API Key。若你想接入 OpenAI 或兼容 OpenAI 格式的中转接口：

1. 复制 `.env.example` 为 `.env`
2. 填入自己的接口信息：

```env
USE_LLM=true
OPENAI_API_KEY=你的密钥
OPENAI_BASE_URL=https://api.openai.com/v1
OPENAI_MODEL=gpt-4.1-mini
```

如果你的服务商是 OpenAI-compatible，只要把 `OPENAI_BASE_URL` 改成服务商提供的 base url，把 `OPENAI_API_KEY` 改成你的 key 即可。

---

## 五、项目结构

```text
ShopPilot_AI_Agent/
├─ app.py                         # Streamlit 网页界面
├─ run_cli.py                     # 命令行入口
├─ requirements.txt               # 依赖
├─ .env.example                   # API 配置示例
├─ README.md                      # 项目说明
├─ SUBMISSION_TEXT.md             # 可直接复制到申请表的文字
├─ data/
│  ├─ sample_products.csv          # 示例竞品数据
│  └─ sample_reviews.csv           # 示例评论数据
├─ outputs/                       # 自动生成结果目录
└─ shoppilot/
   ├─ __init__.py
   ├─ agents.py                   # 多 Agent 核心逻辑
   ├─ config.py                   # 配置读取
   ├─ exporter.py                 # 报告/JSON/CSV 导出
   ├─ llm.py                      # 可选 LLM 调用封装
   ├─ models.py                   # 数据模型
   └─ pipeline.py                 # 总流程编排
```

---

## 六、适合填写的项目成果描述

见 `SUBMISSION_TEXT.md`，里面已经写好了可以直接复制到表单的 1000 字以内版本。
