from __future__ import annotations

from pathlib import Path

import pandas as pd

from shoppilot.config import load_settings
from shoppilot.exporter import export_all
from shoppilot.llm import LLMClient
from shoppilot.models import CompetitorProduct, ProductBrief, ReviewItem
from shoppilot.pipeline import ShopPilotPipeline


def load_competitors(path: str | Path) -> list[CompetitorProduct]:
    df = pd.read_csv(path)
    competitors: list[CompetitorProduct] = []
    for _, row in df.iterrows():
        points = str(row.get("key_selling_points", "")).split("|")
        competitors.append(
            CompetitorProduct(
                title=str(row["title"]),
                price=float(row["price"]),
                rating=float(row["rating"]),
                review_count=int(row["review_count"]),
                monthly_sales=int(row["monthly_sales"]),
                key_selling_points=[p.strip() for p in points if p.strip()],
            )
        )
    return competitors


def load_reviews(path: str | Path) -> list[ReviewItem]:
    df = pd.read_csv(path)
    return [ReviewItem(rating=int(row["rating"]), content=str(row["content"])) for _, row in df.iterrows()]


def main() -> None:
    root = Path(__file__).resolve().parent
    competitors = load_competitors(root / "data" / "sample_products.csv")
    reviews = load_reviews(root / "data" / "sample_reviews.csv")

    product = ProductBrief(
        product_name="Foldable Travel Makeup Bag",
        category="Travel Organizer",
        target_market="United States",
        target_customer="women travelers and daily commuters",
        main_features=[
            "foldable hanging design",
            "water-resistant material",
            "large capacity compartments",
            "easy-to-clean surface",
        ],
        price=19.99,
        cost=7.20,
        selling_platform="Amazon",
    )

    settings = load_settings()
    llm = LLMClient(settings)
    pipeline = ShopPilotPipeline(llm=llm)
    result = pipeline.run(product=product, competitors=competitors, reviews=reviews)
    paths = export_all(result, root / "outputs")

    print("\n✅ ShopPilot 运行完成！")
    print("\n生成文件：")
    for name, path in paths.items():
        print(f"- {name}: {path}")
    print("\n核心结论：")
    print(result.research.summary)
    print(result.listing.summary)
    print(result.compliance.summary)


if __name__ == "__main__":
    main()
